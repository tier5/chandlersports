=== Plugin Name ===
Contributors: XxXYonIXxX
Donate link: http://www.scolpy.net/
Tags: jpeg, jpg, compression, disable
Requires at least: 3.3.1
Tested up to: 4.6
Stable tag: 1.5
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl.html
=== Plugin Name ===
Contributors: leewillis77
Donate link: http://www.leewillis.co.uk/wordpress-plugins/?utm_source=wordpress&utm_medium=www&utm_campaign=woocommerce-gpf
Tags: e-commerce, woocommerce, e-commerce
Requires at least: 3.2
Tested up to: 3.2
Stable tag: 1.5.4
License: GPLv3

== Description ==

A WooCommerce extension that allows you to easily configure data to be added to your Google Merchant Centre feed.

== Installation ==

1. Upload the plugin to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Create your store defaults in WooCommerce > Google Product Feed
4. [Optionally] set defaults for specific product categories
5. [Optionally] set specific values against your products
5. Check your feed

<?php

/**

* The Header for our theme.

*

* Displays all of the <head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252"> section and everything up till <div id="main">

*

* @package WordPress

* @subpackage Twenty_Ten

* @since Twenty Ten 1.0

*/

?><!DOCTYPE html>

<html <?php language_attributes(); ?>>

<head> 



<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="viewport" content="width=device-width, initial-scale=1">

<title>

   <?php global $woocommerce; ?>

<?php

/*

* Print the <title> tag based on what is being viewed.

*/

global $page, $paged;



wp_title( ' | ', true, 'right' );



// Add the blog name.

// bloginfo( 'name' );



// Add the blog description for the home/front page.

$site_description = get_bloginfo( 'description', 'display' );

if ( $site_description && ( is_home() || is_front_page() ) )

echo " | $site_description";



// Add a page number if necessary:

if ( $paged >= 2 || $page >= 2 )

echo ' | ' . sprintf( __( 'Page %s', 'twentyten' ), max( $paged, $page ) );



?></title>

<link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">

<link rel="profile" href="http://gmpg.org/xfn/11" />

<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>?v=<?php echo time(); ?>" />

<link rel="stylesheet" type="text/css" media="all" href="<?=get_stylesheet_directory_uri().'/wc_css.css'?>" />

<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />

<link rel="stylesheet" type="text/css" media="all" href="<?=get_stylesheet_directory_uri().'/css/bootstrap.min.css'?>" />

<link href="<?php bloginfo('template_directory'); ?>/css/style.css" rel="stylesheet" type="text/css">





<link href="<?php bloginfo('template_directory'); ?>/css/stylesheet.css" rel="stylesheet" type="text/css">

<link href="<?php bloginfo('template_directory'); ?>/css/normalize.css" rel="stylesheet" type="text/css">

<link href="<?php bloginfo('template_directory'); ?>/css/menu-style.css" rel="stylesheet" type="text/css">

<link href='http://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css' rel='stylesheet' type='text/css'>

<link href="<?php bloginfo('template_directory'); ?>/css/owl.carousel.css" rel="stylesheet" type="text/css">

<link href="<?php bloginfo('template_directory'); ?>/css/owl.theme.css" rel="stylesheet" type="text/css">

<link href="<?php bloginfo('template_directory'); ?>/css/bootstrap-responsive-tabs.css" rel="stylesheet" type="text/css">

<link href="<?php bloginfo('template_directory'); ?>/css/responsive.css" rel="stylesheet" type="text/css">



<!-- Just for debugging purposes. Don't actually copy these 2 lines! -->

<!--[if lt IE 9]><script src="<?=get_stylesheet_directory_uri()?>/js/ie8-responsive-file-warning.js"></script><![endif]-->

<!--<script src="<?=get_stylesheet_directory_uri()?>/js/ie-emulation-modes-warning.js"></script>-->



<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->

<!--[if lt IE 9]>

<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>

<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>

<![endif]-->





<!--[if IE]>

<link rel="stylesheet" type="text/css" href="/wp-content/themes/chandler/css/ie.css" /> 

<![endif]-->



<?php

/* We add some JavaScript to pages with the comment form

* to support sites with threaded comments (when in use).

*/

if ( is_singular() && get_option( 'thread_comments' ) )

wp_enqueue_script( 'comment-reply' );



/* Always have wp_head() just before the closing </head>

* tag of your theme, or you will break many plugins, which

* generally use this hook to add elements to <head> such

* as styles, scripts, and meta tags.

*/

wp_head();

?>

<!--[if IE]>

<link rel="stylesheet" type="text/css" href="/wp-content/themes/chandler/_iestyle.css" /> 

<![endif]-->

<?php /*

<script type="text/javascript" src="//fast.fonts.com/jsapi/9120d1f2-e488-4043-a9c1-6b5afee262b0.js"></script>

<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>

*/ ?>

<script src="<?=get_stylesheet_directory_uri().'/js/slides.js'?>"></script>

<link rel="stylesheet" type="text/css" media="all" href="<?=get_stylesheet_directory_uri().'/zoom.css'?>" />

<script src="<?=get_stylesheet_directory_uri().'/js/zoom.js'?>"></script>

<script src="<?=get_stylesheet_directory_uri().'/js/high.js'?>"></script>

<script src="<?=get_stylesheet_directory_uri().'/js/bootstrap.min.js'?>"></script>

<script src="<?=get_stylesheet_directory_uri().'/js/custom.js'?>?v=1.2.3"></script>



<script>

jQuery(function($){

if($('#slides').length) {

$("#slides").slides({

generateNextPrev: true,

generatePagination: true,

effect: 'fade'

});

}

if($('#pageslides').length) {

$("#pageslides").slides({

generateNextPrev: true,

generatePagination: true,

effect: 'fade'

});

}

$('.inside-menu').matchHeight();

});



jQuery(function($) {

if($('#singleimg').length) {

$('#singleimg').jqzoom({

zoomType: 'standard',

lens:true,

preloadImages: false,

alwaysOn:false,

zoomWidth: 459,

zoomHeight: 459,

title: false,

xOffset: 28,

yOffset: 0

});

}

//jQuery('.toggle_form').hide();

jQuery(".toggle_hire").click(function(){

jQuery(".toggle_form").toggle();

});

});

/* MAtrix M JS*/

jQuery( document ).ready(function() {

   jQuery('#main li').append('<a href="#" class="show-mega-menu-on-hover" style="display:none;"><img class="img-responsive menu-arrow-image" src="<?=get_stylesheet_directory_uri();?>/images/icons.png"></a>');

}); 

</script>  



</head>



<body <?php body_class(); ?>>





<?php /*

<script>(function(d, s, id) {

var js, fjs = d.getElementsByTagName(s)[0];

if (d.getElementById(id)) return;

js = d.createElement(s); js.id = id;

js.src = "//connect.facebook.net/en_GB/all.js#xfbml=1&appId=427173494029217";

fjs.parentNode.insertBefore(js, fjs);

}(document, 'script', 'facebook-jssdk'));</script>

*/?>



<div class="top_hed">

	<div class="container">

    	<div class="main_top">

        	<div class="col-sm-2">

            	

               <div class="rig_an_lo cf">

				<?php

			 if (is_user_logged_in())

			 {

        $current_user = wp_get_current_user();

		echo "<h1><a href='http://testweb4you.com/projects/chandlersports/my-account/'>My Account</a></h1>

		          <span>or</span><h2>";?>

                     <a href="<?php echo wp_logout_url( home_url() ); ?>">Logout</a>

<?php

                        

       } 

	   else{

        echo "<h1><a href='#' data-toggle='modal' data-target='#login-modal_r'>Register</a></h1>

		          <span>or</span><h2>

				  <a href='#' data-toggle='modal' data-target='#login-modal'>Login</a></h2>";

         }

	?>



                </div>

                

                <div class="modal fade" id="login-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">

                

    	  <div class="modal-dialog">

				<div class="loginmodal-container">

                <button data-dismiss="modal" class="close" type="button">✖</button>

					<h1>Login to Your Account</h1><br>

				   <!----<form>

					<input type="text" name="user" placeholder="Username">

					<input type="password" name="pass" placeholder="Password">

					<input type="submit" name="login" class="login loginmodal-submit" value="Login">

				  </form>--->

                                         

                                         <div class="login"> 

					 <?php echo do_shortcode('[woocommerce_my_account]')?>

					 </div>

                                 



				  <div class="login-help">

					<a href="#">Register</a> - <a href="#">Forgot Password</a>

				  </div>

				</div>

			</div>

		  </div>

          

          

          <div class="modal fade" id="login-modal_r" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">

    	  <div class="modal-dialog">

				<div class="loginmodal-container_1">

                <button data-dismiss="modal" class="close" type="button">✖</button>

			<!---<form role="form">

			<h2>Please Sign Up <small>It's free and always will be.</small></h2>

			<hr class="colorgraph"></hr>

			<div class="row">

				<div class="col-xs-12 col-sm-6 col-md-6">

					<div class="form-group">

                        <input type="text" tabindex="1" placeholder="First Name" class="form-control input-lg" id="first_name" name="first_name">

					</div>

				</div>

				<div class="col-xs-12 col-sm-6 col-md-6">

					<div class="form-group">

						<input type="text" tabindex="2" placeholder="Last Name" class="form-control input-lg" id="last_name" name="last_name">

					</div>

				</div>

			</div>

			<div class="form-group">

				<input type="text" tabindex="3" placeholder="Display Name" class="form-control input-lg" id="display_name" name="display_name">

			</div>

			<div class="form-group">

				<input type="email" tabindex="4" placeholder="Email Address" class="form-control input-lg" id="email" name="email">

			</div>

			<div class="row">

				<div class="col-xs-12 col-sm-6 col-md-6">

					<div class="form-group">

						<input type="password" tabindex="5" placeholder="Password" class="form-control input-lg" id="password" name="password">

					</div>

				</div>

				<div class="col-xs-12 col-sm-6 col-md-6">

					<div class="form-group">

						<input type="password" tabindex="6" placeholder="Confirm Password" class="form-control input-lg" id="password_confirmation" name="password_confirmation">

					</div>

				</div>

			</div>

			<div class="row">

				<div class="col-xs-4 col-sm-3 col-md-3">

					<span class="button-checkbox">

						<button tabindex="7" data-color="info" class="btn btn-default" type="button"><i class="state-icon glyphicon glyphicon-unchecked"></i>I Agree</button>

                        <input type="checkbox" value="1" class="hidden" id="t_and_c" name="t_and_c">

					</span>

				</div>

				<div class="col-xs-8 col-sm-9 col-md-9">

					 By clicking <strong class="label label-primary">Register</strong>, you agree to the <a data-target="#t_and_c_m" data-toggle="modal" href="#">Terms and Conditions</a> set out by this site, including our Cookie Use.

				</div>

			</div>

			

			<hr class="colorgraph">

			<div class="row">

				<div class="col-xs-12 col-md-6"><input type="submit" tabindex="7" class="btn btn-primary btn-block btn-lg" value="Register"></div>

				<div class="col-xs-12 col-md-6"><a class="btn btn-success btn-block btn-lg" href="#">Sign In</a></div>

			</div>

		</form>-->

                                         <div class="registration"> 

			                

					 <?php echo do_shortcode('[woocommerce_my_account]')?>

					 </div>

                            



				</div>

			</div>

		  </div>

                

            </div>

            <div class="col-sm-6">

            	<?php dynamic_sidebar( 'header-topbar-center' ); ?>

            </div>

            <div class="col-sm-4">

            	<div class="right_n">

            	<nav class="navbar navbar-default">

						<div class="nav-bar">

						    <div class="navbar-header">

						      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">

						        <span class="sr-only">Toggle navigation</span>

						        <span class="icon-bar"></span>

						        <span class="icon-bar"></span>

						        <span class="icon-bar"></span>

						      </button>

						    </div>

						    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

						    <?php wp_nav_menu(array('container_class' => '','theme_location' => 'top','menu_class' => 'nav navbar-nav')); ?>

						    </div>

						</div>

					</nav>

                </div>

            </div>

        </div>

    </div>

</div>

<div class="top_logo_headr">

	<div class="container">

    	<div class="col-sm-4">

        	<div class="logo cf">

            	<?php if ( get_theme_mod( 'Client_logo' ) ) : ?>
									<a class="" href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><img class="" src="<?php echo get_theme_mod( 'Client_logo' ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>"></a>
								<?php else : ?>
									<div class="site-introduction">
										<h1 class="site-title"><a href="<?php echo home_url( '/' ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
											<p class="site-description"><?php bloginfo( 'description' ); ?></p> 
                                          
                                            </div>
            		  <?php endif; ?>
            </div>

        </div>

        <div class="col-sm-4 cf">

        	<?php dynamic_sidebar( 'header-topbar-phone' ); ?>

        </div>

        <div class="col-sm-2">

        	<div class="head_search">

                <!---<input type="search" name="search" placeholder="Search" />

                <button><i class="fa fa-search"></i></button>-->

<form action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get">

<input name="s" type="text" placeholder="Search"  onblur="this.value = this.value || this.defaultValue;" onfocus="this.value = '';" />

<button type="submit"><i class="fa fa-search"></i></button>

</form>

            </div>

        </div>

        <div class="col-sm-2">


        	<div class="ri_pd">


        	<div class="righ_cat_b">


                 <a class="cart-contents" href="<?php echo $woocommerce->cart->get_cart_url(); ?>" title="<?php _e('View your shopping cart', 'woothemes'); ?>">


            	<i class="fa fa-shopping-cart"></i>

                <p> <?php echo sprintf(_n('%d item', '%d items', $woocommerce->cart->cart_contents_count, 'woothemes'), $woocommerce->cart->cart_contents_count);?>  - <?php echo $woocommerce->cart->get_cart_total(); ?></p>

</a>

        </div>

            <div class="cart_box">

                    <ul>

                    <li>

                      <div class="lnt-cart-products">

                        <?php echo sprintf(_n('%d item', '%d items', $woocommerce->cart->cart_contents_count, 'woothemes'), $woocommerce->cart->cart_contents_count);?> products added.<span class="lnt-cart-total"><?php echo $woocommerce->cart->get_cart_total(); ?></span>

                      </div>

                    </li>

                    <li>

                      <?php dynamic_sidebar( 'cart-box' ); ?>

                    </li>

                    <li class="lnt-cart-actions">

                      <a class="lnt-view-cart-btn" href="<?php echo do_shortcode('[url]'); ?>/cart/">View cart</a>

                      <a class="lnt-checkout-btn" href="<?php echo do_shortcode('[url]'); ?>/checkout/">Checkout</a>

                    </li>

                  </ul>                         

                  </div>

            </div>

        </div>

    </div>

</div>

<div class="header_nav_bar">

	<div class="container">

    	<div class="menu-container">

          <div class="menu">



	 <?php wp_nav_menu( array( 'container' => false, 'menu_class' => 'false','theme_location' => 'primary' ) );  ?>

           

          </div>

        </div>

    </div>

</div>
<!--------------start of sticky content---------------->
<div class="outside-page-blocks outside-block-left">
        <div class="usps-holder">
<div class="usps">
<ul>
<li class="usp-list-item usp-list-item-1">
<div class="usp-icon"><i class="fa fa-truck" aria-hidden="true"></i></div>
<div class="usp-desc">
<p class="usp-desc--big"><span><strong>Free Delivery</strong></span></p>
<p class="usp-desc--small"><span>on orders over £100<br><span style="font-size: x-small;">(Restrictions apply)&nbsp;</span></span></p>
</div>
</li>
<li class="usp-list-item usp-list-item-2">
<div class="usp-icon"><i class="fa fa-users" aria-hidden="true"></i>
</div>
<div class="usp-desc">
<p class="usp-desc--big"><span><strong>2-Man Delivery & Installation</strong></span></p>
<p class="usp-desc--small"><span>see "super-saver" map for locations</span></p>
</div>
</li>
<li class="usp-list-item usp-list-item-3">
<div class="usp-icon"><i class="fa fa-trash" aria-hidden="true"></i>
</div>
<div class="usp-desc">
<p class="usp-desc--big"><span><strong>Rubbish Removal</strong></span></p>
<p class="usp-desc--small"><span>after installation</span></p>
</div>
</li>
<li class="usp-list-item usp-list-item-4">
<div class="usp-icon"><i class="fa fa-wrench" aria-hidden="true"></i>
</div>
<div class="usp-desc">
<p class="usp-desc--big"><span><strong>Hire Before You Buy</strong></span></p>
<p class="usp-desc--small"><span>on most fitness equipment products</span></p>
</div>
</li>
<li class="usp-list-item usp-list-item-5">
<div class="usp-icon"><i class="fa fa-sitemap" aria-hidden="true"></i>
</div>
<div class="usp-desc">
<p class="usp-desc--big"><span><strong>Ordering Multiple Items?</strong></span></p>
<p class="usp-desc--small"><span>Call us for a discount</span></p>
</div>
</li>
<li class="usp-list-item usp-list-item-6">
<div class="usp-icon"><i class="fa fa-home" aria-hidden="true"></i>
</div>
<div class="usp-desc">
<p class="usp-desc--big"><span><strong>Leasing Available</strong></span></p>
<p class="usp-desc--small"><span>for commercial sites</span></p>
</div>
</li>
<li class="usp-list-item usp-list-item-7">
<div class="usp-icon"><i class="fa fa-archive" aria-hidden="true"></i>
</div>
<div class="usp-desc">
<p class="usp-desc--big"><span><strong>Over 600 Products</strong></span></p>
<p class="usp-desc--small"><span>with more being added weekly</span></p>
</div>
</li>
</ul>
</div>
</div>    </div>



<!----end of sticky content--------------------------->

<?php
/**
 * Login Form
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */

global $woocommerce; ?>

<?php $woocommerce->show_messages(); ?>

<?php do_action('woocommerce_before_customer_login_form'); ?>

<?php if (get_option('woocommerce_enable_myaccount_registration')=='yes') : ?>

<div class="col2-set" id="customer_login">

	<div class="col-1">

<?php endif; ?>

		<form method="post" class="login wcloginform">
        
			
				<?php /*?><label for="username"><?php _e('Username or email', 'woocommerce'); ?><span class="required">*</span></label><?php */?>
                <!--<input type="text" name="user" placeholder="Username">-->
				<input type="text" placeholder="Username" name="username"/>
			
				<?php /*?><label for="password"><?php _e('Password', 'woocommerce'); ?> <span class="required">*</span></label><?php */?>

                <?php /*?><input type="password" name="pass" placeholder="Password"><?php */?>
				<input type="password" name="password" placeholder="Password" />
			
			    <div class="clear"></div>

			    <?php $woocommerce->nonce_field('login', 'login') ?>
				<input type="submit" class="login loginmodal-submit" name="login" value="<?php _e('Login', 'woocommerce'); ?>" />
				<a class="lost_password" href="<?php echo esc_url( wp_lostpassword_url( home_url() ) ); ?>"><?php _e('Lost Password?', 'woocommerce'); ?></a>
			
		</form>

<?php if (get_option('woocommerce_enable_myaccount_registration')=='yes') : ?>

	</div>

	<div class="col-2">

		<h2><?php // _e('Register', 'woocommerce'); ?></h2>
        <h2>Please Sign Up <small>It's free and always will be.</small></h2>
	    <hr class="colorgraph">        
		<form method="post" class="register">
        
			<?php if ( get_option( 'woocommerce_registration_email_for_username' ) == 'no' ) : ?>
			<div class="row">
            </div>
            
            <div class="form-group">
				<?php /*?><label for="reg_username"><?php _e('Username', 'woocommerce'); ?> <span class="required">*</span></label><?php */?>
					<input type="text" class="form-control input-lg" id="first_name" placeholder="username" name="username" id="reg_username" value="<?php if (isset($_POST['username'])) echo esc_attr($_POST['username']); ?>" />
			</div>

			<p class="form-row form-row-last">
                        
                        <?php else : ?>

		        <p class="form-row form-row-wide">

			<?php endif; ?>

		<div class="form-group">

		     <?php /*?><label for="reg_email"><?php _e('Email', 'woocommerce'); ?><span class="required">*</span></label><?php */?>
                     <input type="email" id="email" placeholder="Email Address" class="form-control input-lg input-text" name="email" id="reg_email" value="<?php if (isset($_POST['email'])) echo esc_attr($_POST['email']); ?>" />
		
                   </p>
      	</div>

			<div class="clear"></div>
<div class="row">

<div class="col-xs-12 col-sm-6 col-md-6">

			<div class="form-group">
			
				<?php /*?><label for="reg_password"><?php _e('Password', 'woocommerce'); ?> <span class="required">*</span></label><?php */?>

				<input type="password" placeholder="Password" class="form-control input-lg" name="password" id="reg_password password" value="<?php if (isset($_POST['password'])) echo esc_attr($_POST['password']); ?>" />
		
       	</div>
</div>
	  <div class="col-xs-12 col-sm-6 col-md-6">
		  <div class="form-group">

			<?php /*?><label for="reg_password2"><?php _e('Re-enter password', 'woocommerce'); ?> <span class="required">*</span></label><?php */?>
                        <input type="password" placeholder="Confirm Password" class="form-control input-lg" name="password2" id="reg_password2 password_confirmation" value="<?php if (isset($_POST['password2'])) echo esc_attr($_POST['password2']); ?>" />
			
          </div>
      </div>
 </div>           
			<div class="clear"></div>

			<!-- Spam Trap -->
			<div style="left:-999em; position:absolute;"><label for="trap">Anti-spam</label><input type="text" name="email_2" id="trap" /></div>

			<?php do_action( 'register_form' ); ?>
	
        <hr class="colorgraph">
        <div class="row">
				<div class="col-xs-12 col-md-6">
                <?php $woocommerce->nonce_field('register', 'register') ?>
				<input type="submit" class="btn btn-primary btn-block btn-lg" name="register" value="<?php _e('Register', 'woocommerce'); ?>" />
                <!--<input type="submit" tabindex="7" class="btn btn-primary btn-block btn-lg" value="Register">-->
                </div>
				<div class="col-xs-12 col-md-6">
                <a class="btn btn-success btn-block btn-lg" href="#">Sign In</a>
                </div>
		</div>
	</form>
	</div>

</div>
<?php endif; ?>

<?php do_action('woocommerce_after_customer_login_form'); ?>
<?php
/**
 * Related Products
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */

global $product, $woocommerce_loop;

$related = $product->get_related();

if ( sizeof($related) == 0 ) return;

$args = apply_filters('woocommerce_related_products_args', array(
	'post_type'				=> 'product',
	'ignore_sticky_posts'	=> 1,
	'no_found_rows' 		=> 1,
	'posts_per_page' 		=> 4,
	'orderby' 				=> $orderby,
	'post__in' 				=> $related
) );

$products = new WP_Query( $args );

$woocommerce_loop['columns'] 	= $columns;

if ( $products->have_posts() ) : ?>

	<div class="col-lg-12 col-xs-12 col-sm-12 col-md-12  upsells products">

		<h4><?php _e('Related Products', 'woocommerce'); ?></h4>

		<ul class="products">

			<?php $i=1; while ( $products->have_posts() ) : $products->the_post(); ?>
			
				<li class="related-products-li col-lg-3 col-sm-3 col-md-3 col-xs-12 product<?php echo $i; ?>">
					<?php //woocommerce_get_template_part( 'content', 'product' ); ?>
					<?php $image = wp_get_attachment_image_src( get_post_thumbnail_id(),'large'); ?>
					<?php if($image[0] != NULL): ?>
						<a href="<?php the_permalink(); ?>"><img src="<?php echo $image[0]; ?>" border="0" /></a>
					<?php endif; ?>
					<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>


					<?php $the_price = get_post_meta( $products->post->ID, '_regular_price', true); ?>
					<p class="theprice">&pound;<?php echo $the_price; ?></p>
					<?php /*if(get_field('recommended_retail_price', $products->post->ID) != NULL): ?>
						<p class="normalprice">Normal price &pound;<span><?php the_field('recommended_retail_price', $products->post->ID); ?></span></p>
					<?php endif;*/ ?>

<?php $related_product = new WC_Product($products->post->ID)  ?>
<?php if($related_product->sale_price != NULL): ?>
	<p class="bigred">Sale &pound;<?php echo $related_product->sale_price; ?></p>
    <p>SAVE &pound;<?php echo floatval($the_price) - floatval($related_product->sale_price); ?> 
<?php endif; ?>
<?php if(get_field('product_listing_info')): ?>
	<div class="product_list_info">
		<?php the_field('product_listing_info'); ?>
	</div>
<?php endif; ?>
				</li>
			<?php if($i==4): $i=1; else: $i++; endif; endwhile; // end of the loop. ?>

		</ul>

	</div>

<?php endif;

wp_reset_postdata();
?>
<!--<img src="/wp-content/themes/chandler/images/bottomline.png" style="max-width: 940px; width: 940px; margin: 0 auto 20px auto;" />-->	

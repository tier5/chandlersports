<?php
/**
 * Single Product tabs
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */

// Get tabs
ob_start();

do_action('woocommerce_product_tabs');

$tabs = trim( ob_get_clean() );

if ( ! empty( $tabs ) ) : ?>
	<div class="col-lg-12 col-xs-12 col-sm-12 col-md-12 woocommerce_tabs">
		<ul class="tabs">
			<?php echo $tabs; ?>
			<li class="delivery_tab"><a href="#tab-delivery">Delivery Options</a></li>
		</ul>
		<?php do_action('woocommerce_product_tab_panels'); ?>
		
		<div class="panel entry-content" id="tab-delivery" style="display: block;">
			<div id="page">
				<?php the_field('delivery_options', 'option'); ?>
			</div>
		</div>

	</div>
<?php endif; ?>
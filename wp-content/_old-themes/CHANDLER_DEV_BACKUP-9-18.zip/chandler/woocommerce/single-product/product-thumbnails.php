<?php
/**
 * Single Product Thumbnails
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */

global $post, $woocommerce;
?>
<div class="rollover_outer"><p id="rollover"><img class="rollover_image" src="<?php echo home_url().'/wp-content/themes/chandler/images/glasszoom.png'?>">Click image to enlarge</p></div>
<div class="thumbnails" id="thumbnailcontainer">
<?php
	$attachments = get_posts( array(
		'post_type' 	=> 'attachment',
		'numberposts' 	=> -1,
		'post_status' 	=> null,
		'post_parent' 	=> $post->ID,
		'post__not_in'	=> array( get_post_thumbnail_id() ),
		'post_mime_type'=> 'image',
		'orderby'		=> 'menu_order',
		'order'			=> 'ASC'
	) );
	if ($attachments) {

		$loop = 0;
		$columns = apply_filters( 'woocommerce_product_thumbnails_columns', 3 );
		
		foreach ( $attachments as $key => $attachment ) {

			if ( get_post_meta( $attachment->ID, '_woocommerce_exclude_image', true ) == 1 )
				continue;

			$classes = array( 'zoom' );

			if ( $loop == 0 || $loop % $columns == 0 )
				$classes[] = 'first';

			if ( ( $loop + 1 ) % $columns == 0 )
				$classes[] = 'last';
		
			$image = wp_get_attachment_image_src( get_post_thumbnail_id(),'large');
		?>
			<?php if($loop==0): ?>
				<a href="javascript:void(0);" title="image" rel="{gallery: 'thumbnails', smallimage: '/thumb.php?src=<?php echo $image[0]; ?>&w=400&s=1',largeimage: '<?php echo $image[0]; ?>'}" class="zoomThumbActive"><img src="/thumb.php?src=<?php echo $image[0]; ?>&w=90&s=1" border="0" /></a>
			<?php endif; ?>
			<a href="javascript:void(0);" title="image" rel="{gallery: 'thumbnails', smallimage: '/thumb.php?src=<?php echo $attachment->guid; ?>&w=400&s=1', largeimage: '<?php echo $attachment->guid; ?>'}">
				<img src="/thumb.php?src=<?php echo $attachment->guid; ?>&w=90&s=1" border="0" />
			</a>
		
		<?php 
			//printf( '<a data-href="%s" href="javascript:void(0);" title="%s" rel="" class="%s zoomThumbActive">%s</a>', wp_get_attachment_url( $attachment->ID ), esc_attr( $attachment->post_title ), implode(' ', $classes), wp_get_attachment_image( $attachment->ID, apply_filters( 'single_product_small_thumbnail_size', 'shop_thumbnail' ) ) );

			$loop++;

		}

	}
?>

	<?php if(get_field('product_video') != NULL): ?>
		<br style="clear: both;" />
		<br style="clear: both;" />
		<p style="margin: 0 0 10px 0;"><strong>Product Video</strong></p>
		<?php $video = explode('v=', get_field('product_video')); ?>
		<iframe width="419" height="236" src="http://www.youtube.com/embed/<?php echo $video[1]; ?>" frameborder="0" allowfullscreen></iframe>
	<?php endif; ?>

</div>
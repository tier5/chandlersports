<?php
/**
 * Single Product title
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */
?>

	<?php if(get_field('brand_logo') != NULL): ?>
		<img src="<?php echo get_field('brand_logo'); ?>" id="brand-logo" />
	<?php endif; ?>
	
	<br style="clear: both;" />

	<h1 itemprop="name" class="product_title entry-title" style="width: 460px;"><?php the_title(); ?></h1>
	<?php my_print_starss(); ?>
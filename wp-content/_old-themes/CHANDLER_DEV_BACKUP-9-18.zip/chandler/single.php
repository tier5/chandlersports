<?php
/**
 * The Template for displaying all single posts.
 *
 * @package WordPress
 * @subpackage Twenty_Ten
 * @since Twenty Ten 1.0
 */

get_header(); ?>
	
		<div class="col-lg-8 col-xs-12 col-sm-8 col-md-8 left-content singalpost">
			<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
				<h1><?php the_title(); ?></h1>
								
				<div class="postedmeta">Posted on <span><?php the_date('F, d Y'); ?></span> by <span><?php the_author(); ?></span></div>
				
				<?php the_content(); ?>
				
				<p id="postedin"><?php twentyten_posted_in(); ?></p>
				
				<div class="fb-comments" data-href="<?php the_permalink(); ?>" data-width="560" data-num-posts="100"></div>

			<?php endwhile; ?>
		</div>
		
		<div class="col-lg-4 col-xs-12 col-sm-4 col-md-4 right-content singalpost">
		
			<div class="side_icons">
				<a href="#"><img src="/wp-content/themes/chandler/images/fb-btn.png" border="0" /></a>
				<a href="#"><img src="/wp-content/themes/chandler/images/twitter-btn.png" border="0" /></a> 
				<a href="#"><img src="/wp-content/themes/chandler/images/gplusbtn.png" border="0" /></a>
			</div>
		
			<?php get_sidebar(); ?>		
		</div>
		
		<br style="clear: both;" />

<?php get_footer(); ?>

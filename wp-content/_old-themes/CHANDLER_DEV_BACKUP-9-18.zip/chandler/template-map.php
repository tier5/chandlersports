<?php
/**
 * Template Name: Map
 */

get_header(); ?>

	<div id="page" class= "map-class">
		<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
			<h1><?php the_title(); ?></h1>
			
			<div class="field-class" >
				<?php if(get_field('map') != NULL): ?>
					<img src="<?php echo get_field('map'); ?>" border="0" alt="Delivery Map" />
				<?php endif; ?>
			</div>
			
			<div  class="field-class" >
				<?php the_content(); ?>
			</div>
			
		<?php endwhile; ?>
	</div>
	
	<br style="clear: both;" />

<?php get_footer(); ?>

<?php
/**
* Template Name: Commercial Fitness
*/

get_header(); ?>

<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>

<?php if(get_field('slider')): ?>
	<div id="slides">
		<div class="slides_container">
			<?php while(the_repeater_field('slider')): ?>
				<div style="background-image: url(<?php echo get_sub_field('image'); ?>);">
					<a href="<?php echo get_sub_field('page_link'); ?>" style="display: block; width: 940px; height: 300px;">
						<?php if(get_sub_field('title') != NULL): ?>
						<div id="content">
							<h3><?php echo get_sub_field('title'); ?></h3>
							<p><span>"</span><?php echo get_sub_field('text'); ?><span>"</span></p>
						</div>
						<?php endif; ?>
					</a>
				</div>
			<?php endwhile; ?>
		</div>
	</div>
<?php endif; ?>

<div id="page" class="col-lg-12 col-xs-12 col-sm-12 col-md-12 no-padding">
	<?php if(get_field('logo_list') != NULL): ?>
	<!--	<div id="commercial_people">
			<?php while(the_repeater_field('logo_list')): ?>
				<img src="<?php echo get_sub_field('logo'); ?>" alt="<?php echo get_sub_field('company_name'); ?>" />
			<?php endwhile; ?>
		</div>-->
	<?php endif; ?>

<?php /*
<h2 class="h2-commercial">Commercial Fitness Equipment Services</h2>
<div id="commercial_services">
	<?php if(get_field('fitness_equipment_services') != NULL): ?>
		<?php $i=1; while(the_repeater_field('fitness_equipment_services')): ?>
			<div class="coms<?php echo $i; ?>">
				<a href="<?php echo get_sub_field('page_link'); ?>"><img src="<?php echo get_sub_field('image'); ?>" alt="<?php echo get_sub_field('title'); ?>" /></a>
				<h3><a href="<?php echo get_sub_field('page_link'); ?>"><?php echo get_sub_field('title'); ?></a></h3>
			</div>
		<?php $i++; endwhile; ?>
	<?php endif; ?>
</div>
			*/ ?> 
<!--<span class="bhr-m"></span> -->

<?php if(get_field('commercial_gym_supply') != NULL): ?>
	<div class="commercial-fitness col-lg-12 col-xs-12 col-sm-12 col-md-12">		
			<h2>Commercial Gym Supply</h2>
			<?php $closed = true;  $i=1; while(the_repeater_field('commercial_gym_supply')): ?>
				<?php
				if( $i == 1 ){ echo '<div  class="col-lg-12 col-xs-6 col-sm-12 col-md-12 fitness_row_commercial">'; $closed = false; }
				?>
				<div class="col-lg-3 col-xs-12 col-sm-3 col-md-3  min-height-fitness fitness<?php echo $i; ?>">
					<a href="<?php echo get_sub_field('page_link'); ?>"><img class="img-responsive" src="<?php echo get_sub_field('image'); ?>" alt="<?php echo get_sub_field('title'); ?>" border="0" /></a>
					<h3><a href="<?php echo get_sub_field('page_link'); ?>"><?php echo get_sub_field('title'); ?></a></h3>
					<?php
					if(get_sub_field('commercial_product_category')):
						echo '<ul class="childfit">';
						$child = get_sub_field('commercial_product_category');
						foreach($child as $aterm):
							$term = get_term($aterm, 'product_cat');
							$alink = get_term_link($aterm);
							echo '<li><a href="'.$alink.'">'.$aterm->name.'</a></li>';
						endforeach;
						echo '</ul>';
					endif;
					?>
				</div>
				<?php
				if( $i == 4 ){ echo "</div>"; $closed = true; }
				?>
				<?php if($i==4): $i=1; else: $i++; endif; endwhile; ?>
				<?php
		if( !$closed ){ echo "</div>"; }
		?>	
	</div>
<?php endif; ?>

<div class="col-lg-12 col-xs-12 col-sm-12 col-md-12 commercial-case-studies">
		
<div id="kurt" class="col-lg-3 col-xs-12 col-sm-4 col-md-3 commercial-kurt">
	<h2>Fitness Equipment Services</h2>
	<ul>
		<li>
			<a href="/gym-equipment-spare-parts-edinburgh/"><img src="<?=get_stylesheet_directory_uri().'/images/I1.jpg'?>"></a>
			<a href="/gym-equipment-spare-parts-edinburgh/">Spare Parts</a>
		</li>
		<li>
			<a href="/commercial-gym-edinburgh/"><img src="<?=get_stylesheet_directory_uri().'/images/I2.jpg'?>"></a>
			<a href="/commercial-gym-edinburgh/">Repairs</a>
		</li>
		<li>
			<a href="/commercial-gym-edinburgh/cabling-services/"><img src="<?=get_stylesheet_directory_uri().'/images/I3.jpg'?>"></a>
			<a href="/commercial-gym-edinburgh/cabling-services/">Cabling Service</a>
		</li>
		<li>
			<a href="/commercial-gym-edinburgh/upholstery-repairs/"><img src="<?=get_stylesheet_directory_uri().'/images/I4.jpg'?>"></a>
			<a href="/commercial-gym-edinburgh/upholstery-repairs/">Upholstery</a>
		</li>
		<li>
			<a href="/gym-equipment-servicing-maintenance-contracts-edinburgh/"><img src="<?=get_stylesheet_directory_uri().'/images/I5.jpg'?>"></a>
			<a href="/gym-equipment-servicing-maintenance-contracts-edinburgh/">Service &amp; Maintenance Contracts</a>
		</li>
		<li>
			<a href="/gym-equipment-servicing-maintenance-contracts-edinburgh/delivery-installations-relocation/"><img src="<?=get_stylesheet_directory_uri().'/images/I6.jpg'?>"></a>
			<a href="/gym-equipment-servicing-maintenance-contracts-edinburgh/delivery-installations-relocation/">Delivery, Installation &amp; Relocation</a>
		</li>
	</ul>
</div>
<div class="col-lg-9 col-xs-12 col-sm-9 col-md-9 client-case-h">
	<h2 class="">Client Case Studies</h2>	
	<?php if(get_field('case_studies') != NULL): ?>
		<ul id="case-studies">
			<?php while(the_repeater_field('case_studies')): ?>
				<li><a href="<?php echo get_sub_field('page_link'); ?>" style="background-image: url(<?php echo get_sub_field('image'); ?>);"><?php echo get_sub_field('title'); ?></a></li>
			<?php endwhile; ?>
		</ul>
	<?php endif; ?>
	<div id="SEO-text">
	<?php echo the_field('seo_content_text'); ?>
	</div>
</div>
</div>
</div>
<?php endwhile; ?>
<?php get_footer(); ?>

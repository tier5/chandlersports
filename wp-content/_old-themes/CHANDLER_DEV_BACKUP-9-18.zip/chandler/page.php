<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package WordPress
 * @subpackage Twenty_Ten
 * @since Twenty Ten 1.0
 */

get_header(); ?>
	<div class="col-lg-8 col-xs-12 col-sm-8 col-md-8 left-content">
		<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
			<h4 class="page-title-h4"><?php the_title(); ?></h4>
			<?php the_content(); ?>
		<?php endwhile; ?>
	</div>
	
	<div class="col-lg-4 col-xs-12 col-sm-4 col-md-4 right-content">	
		<div class="side_icons">
			<a href="https://www.facebook.com/chandlersports?ref=ts&fref=ts"><img src="/wp-content/themes/chandler/images/fb-btn.png" border="0" /></a> 
			<a href="https://plus.google.com/+ChandlersportsCoUk/posts"><img src="/wp-content/themes/chandler/images/gplusbtn.png" border="0" /></a>
			<a href="https://www.youtube.com/user/chandlersports"><img src="/wp-content/themes/chandler/images/mm-youtube.png" border="0" /></a>
		</div>
		
		<div class="widget-container">
			<?php
				if($post->ID == 15 || $post->post_parent == 15 || in_array($post->ID, array(1294,1104))):
					wp_nav_menu(array('menu' => 70, 'menu_class' => 'sidenav', 'walker' => new WPBR_938753_PROD_CAT_Custom_Walker));
				else:
					if($post->post_parent) {
					    $post_ancestors = get_post_ancestors($post->ID);
					    $post_root = count($post_ancestors)-1;
					    $post_parent = $post_ancestors[$post_root];
					    $title = get_the_title($post_ancestors[$post_root]);
					} else {
					    $post_parent = $post->ID;
					    $title = get_the_title($post->ID);
					}
					$children = wp_list_pages(array(
						'title_li'  => '',
						'child_of'  => $post_parent,
						'echo'      => 0,
						'depth'     => 1,
						'walker'    => new WPBR_938753_POST_Custom_Walker()
					));
					if($children) {
					    echo '  <h3>'.$title.'</h3><div class="widget-line"></div>'."\n";
					   echo '  <ul class="sidenav">'."\n";
					    echo        $children."\n";
					    echo '  </ul>'."\n"; 
					}
				endif;
				echo '</div>';
				echo '<div id="testimonailwidget-2" class="widget widget-container TestimonailWidget">
						<h3 class="widget-title testimonial-h3">Testimonials</h3>
						<div class="widget-line testimonial-widget-line"></div>
						<script type="text/javascript">
							jQuery(document).ready(function(){
								jQuery("#testimonial").bxSlider({ 
									adaptiveHeight: true,
									adaptiveHeightSpeed: 500,
									mode: "horizontal",
									pager: false,
									auto: true,
									controls: true,
									speed:500,
									pause:3000,
									touchEnabled: true,
									autoHover: true,
								    nextSelector: ".br-bx-next",
								    prevSelector: ".br-bx-prev",
								    nextText: "",
								    prevText: ""
								});
							});
						</script>
						';
					echo do_shortcode('[testimonials_slider]');
			?>
		</div>
	</div>	
	<br style="clear: both;" /> 

<?php get_footer(); ?> 

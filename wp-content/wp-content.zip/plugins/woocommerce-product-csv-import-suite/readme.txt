=== WooCommerce Product CSV Import Suite ===

For help see the docs: http://www.woothemes.com/woocommerce-docs/user-guide/product-csv-import-suite/
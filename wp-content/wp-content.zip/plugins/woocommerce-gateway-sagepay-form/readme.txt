=== WooCommerce SagePay Form SagePay Direct Gateway ===

Extends WooCommerce. Provides a SagePay Form AND SagePay Direct gateway for WooCommerce. http://www.sagepay.com. Email support@addonenterprises.com with any questions. If you need technical support please turn on debugging and supply the contents of the debug emails.

Please copy the 'woocommerce-gateway-sagepay-form' to your wp-content/plugins folder to install.

Protocol 3 requires PHP mcrypt be installed on your server

Test Cards

Use the following credit card numbers for testing.

Visa (VISA)
4929000000006

MasterCard (MC)
5404000000000001

Visa Debit / Delta (DELTA)
4462000000000003

Solo (SOLO)
6334900000000005
Issue 1

UK Maestro / International Maestro (MAESTRO)
5641820000000005
Issue 01

American Express (AMEX)
374200000000004

Visa Electron (UKE)
4917300000000008

If you have 3D-Secure set up on your test account, you can use the My Sage Pay interface to switch on the checks at this stage to test your 3D-Secure Terminal URL script against a simulation of the 3D-Secure environment.
In test mode, to simulate successful payment the first line of the address must be '88' and the postcode should be '412'.

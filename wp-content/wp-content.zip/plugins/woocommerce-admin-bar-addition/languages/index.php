<?php
/**
 * Do not put custom translations here. They will be deleted on 'WooCommerce Admin Bar Addition' updates!
 *
 * Keep custom 'WooCommerce Admin Bar Addition' translations
 *    in '/wp-content/languages/woocommerce-admin-bar-addition/'
 */
